# Penjelasan Implementasi Tugas

## Kesesuaian dengan petunjuk

| Konsep | Implementasi |
|---|---|
| Variable | `inputSaatIni`, `angkaSebelumnya`, dan `operatorAktif` menyimpan keadaan kalkulator. |
| Operator | `+`, `−`, `×`, dan `÷` dihitung pada method `Hitung`. |
| If/Switch | Percabangan `if` memeriksa kondisi input; switch expression memilih operasi hitung. |
| Method | Contoh: `MasukkanAngka`, `PilihOperator`, `HitungHasil`, dan `Bersihkan`. |
| Class | `CalculatorEngine` menjadi cetak biru logika kalkulator. |
| Object | `mesinKalkulator = new CalculatorEngine()` adalah object yang dipakai GUI. |
| Event | Klik tombol dan input keyboard memicu event. |
| Handler | Contoh: `SaatAngkaDiklik` dan `SaatOperatorDiklik`. |
| Form/Window | `MainWindow` merupakan jendela utama aplikasi. |
| Button | Tombol angka, operator, fungsi, dan hasil dibuat di `MainWindow.axaml`. |
| TextBox/Display | `TampilanText` dan `RiwayatText` menampilkan angka serta operasi. |
| Label | Judul terminal, teknologi, dan label Linux menggunakan `TextBlock`. |
| Error handling | `JalankanAman` memakai `try/catch/finally`, termasuk pembagian dengan nol. |

## Alur program

1. Pengguna menekan tombol angka.
2. Event klik diterima oleh handler di `MainWindow.axaml.cs`.
3. Handler memanggil method pada object `CalculatorEngine`.
4. `CalculatorEngine` mengolah dan menyimpan nilai.
5. GUI membaca kembali `Tampilan` dan `Riwayat` untuk ditampilkan.
6. Jika terjadi kesalahan, `try/catch` menampilkan pesan tanpa membuat aplikasi crash.

## Script presentasi singkat

“Aplikasi saya bernama TuxCalc, yaitu kalkulator C# .NET dengan tampilan bertema Linux. GUI dibuat dengan Avalonia karena dapat berjalan di Ubuntu, Windows, dan macOS. Logika hitung saya pisahkan ke class `CalculatorEngine`, kemudian `MainWindow` membuat object dari class tersebut. Ketika button ditekan, event handler memanggil method yang sesuai. Operasi dipilih menggunakan switch expression. Seluruh aksi dibungkus `try/catch`, sehingga kesalahan seperti pembagian dengan nol tidak membuat aplikasi crash.”
