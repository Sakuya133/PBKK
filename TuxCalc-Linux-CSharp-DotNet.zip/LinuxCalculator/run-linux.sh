#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"
dotnet restore
dotnet run
